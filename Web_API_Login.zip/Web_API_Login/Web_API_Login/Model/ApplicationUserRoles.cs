﻿namespace Web_API_Login.Model
{
    public static class ApplicationUserRoles
    {
        public static string? Admin = "Admin";
        public static string? User = "User";
    }
}
